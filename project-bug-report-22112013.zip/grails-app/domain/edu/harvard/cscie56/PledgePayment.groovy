package edu.harvard.cscie56

class PledgePayment {
	PledgeImpl impl
	Float amountPaid
	Date paymentDate
	
}
