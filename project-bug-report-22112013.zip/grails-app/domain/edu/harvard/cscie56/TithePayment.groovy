package edu.harvard.cscie56

class TithePayment {
	Tithe tithe
	Float amount
	String datePaid
	String titheMonth
	String titheYear
	String acceptedBy
    static constraints = {
    }
	
	static mapping = {
		version false
	}
}
