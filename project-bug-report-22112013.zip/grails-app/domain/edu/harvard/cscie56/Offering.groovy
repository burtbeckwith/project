package edu.harvard.cscie56

class Offering {

    String service
    Float amountCheck
    Float amountCash
    String offeringDate
    String approvedBy
    static constraints = {
    }
    static mapping = {
        version false
    }
}
