package edu.harvard.cscie56

class PledgeImpl {
	Members member
	Pledge pledge
	Float amount
	static constraints = {
	}
}
