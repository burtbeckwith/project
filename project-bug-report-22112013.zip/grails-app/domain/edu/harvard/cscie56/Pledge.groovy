package edu.harvard.cscie56

class Pledge {

	String pledgeName
	Date dateCreated
	String createdBy
	Date dueDate
	
    static constraints = {
    }
}
