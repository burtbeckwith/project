package edu.harvard.cscie56

class Attendance {

	String service
	String serviceDate
	Long memberNumber
	Long guestNumber
	Long childrenNumber
	Long adultsNumber
	String createdBy
	String dateCreated
    static constraints = {
    }
}
